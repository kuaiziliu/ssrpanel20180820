<?php


namespace App\Http\V2Ray;


class EmptyClass
{

}